# Varied Dialogues Mod

## Installation

1. Copy this entire folder to `mods/varied_dialogues/`
2. Launch the game
3. Enjoy enhanced dialogues!

## Features

- Psychological dialogue system
- Context-aware responses
- 400+ dialogue variations
- Rough sex combinations
- Personality-based responses

## Version

**0.1-154489a**

## Support

For bug reports, please mention the version number above.
