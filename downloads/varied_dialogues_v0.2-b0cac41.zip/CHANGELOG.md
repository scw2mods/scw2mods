# Varied Dialogues Mod - Changelog
Varied Dialogues is a mod for Strip Club Wars 2 that transforms repetitive sexual dialogue into a dynamic, psychologically-aware system.

## Version 0.2 (Current)
- **Orgasm Variations**: Added 8 variations for each orgasm dialogue type (160 new lines total)
- **Dynamic Decision Block Hack**: Workaround for TFL limitation to enable random variations in decision dialogues
- **Enhanced Cache System**
- SCW 2.07 compatibility

## Version 0.1
- Core psychological system with 400+ dialogue variations
- Rough sex combination support (25 psychological pairings)
- Variation system for main sexual actions
- Modular architecture with TFL patch system
- Automatic build with optimized cache generation
- Complete documentation and professional build system