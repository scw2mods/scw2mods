KingTut Mod for StripClubWars 2 v1.60

Note: when updating the mod, make sure to delete the folder <game>/runtime/tfel/king_tut
      to make sure the game recompiles and you run the latest version

Note: Various parts of the MOD can be enabled/disabled by going to the '<Cheat MC>' option in your office


## Interactions:

# Offer Job (Also AI)
When no jobs are posted for your Club, you can offer a job directly to any character
you meet (based on available jobs in your club)

# Workout Together (also AI)
In the gym you can work out together with any character applying the same bonuses
to them as when you work out by yourself (minor gain for yourself)

# Swimming Together (also AI)
When at the beach you can go and take someone for a swim together, when
she likes you enough you might take her to the nude beach (if available) and
have some extra fun
This option is also available at the pool area of the various clubs.


## Actions:

# Go to Auxiliary
When at the office the button will change to quickly go to the auxiliary office to talk
with your managers


## Events:

# Workout Routine (AI only)
Characters in the game will go into the gym and do their own
workouts (gains depend on their lifestyle and availability)

# Financial Aid (Also AI)
Any club employee can ask their boss (club owner) to help them
to repay their debt. When you fully pay their debt you get an extra bonus.
Only triggers when club owner has sufficient cash and various circumstances are favourable.

# Stable Relations
Each month a modifier will be applied automatically to employees, friend, romantic partners
and followers (if controlling moral police) as well as a small happiness boost.
This reduces the micro-management of employees and relationships happiness and their opinion of the MC.

## Extras:
- Added various names for extra variation


## Cheat module

This module is intended to simplify game-play without breaking the game, so certain attributes won't be set to
allow for many aspects of the game to still work as intended, but it will remove the more tedious aspects that
would require repeating the same actions over and over with every character.

# Characters
When interacting with a character there is a '<Cheat Char>' option, based on
their status (random, employee, romantic) various cheat options:
- any char: match opinions and physical attraction to MC (easier to date)
- any char: reset to good health / happiness and remove injuries / stress (only visible if below thresholds)
- any char: change appearance (select new image for character)
- any char: learn her traits and opinions (learn by category)
- any char: set 'eternal love' modifier (basically prevent attraction decay)
- romantic: make a loyal partner (hates polyamory and related options, wholesome relations)
- romantic: make a polyamorous partner (hates monogamy and related options, open relations)
- employee: set stats and attributes to good baseline for her job (make your employee efficient at her job)
- employee: make her salary match other employees with same job (only visible when more people with same job)
- employee: decrease salary by 20% (so you can manage salary for single jobs, raise by 'Discuss Work')
- employee: set college degree matching her current job (minor skill boost, not for students)
- commissioner: set opinions and attributes to make passing laws easier

In addition it will show the following extra information:
- current job information including salary and the person's overall attractiveness
- when having a college degree the actual degree and some information on the jobs that would suit them best
- when still going to the university just display that information

NOTE: some cheats will be disabled for special story characters to prevent corrupting story lines

# Main Character
When in your office show option '<Cheat MC>' with the following options:
- set base health / happiness to 90 and remove injuries / illness
- add 3 new good looking AI characters (configurable age, gender and sexual orientation)
- set MC sexual options to love based on sexual proclivity (only available once)
- set MC opinions for running a strip club to love (only available once)

When comfortable with editing tfl files -> you can enable cheat logging by editing
king_cheat.tfl line 43 and 86 to "$log = true;" so you can see what is changed during cheating (debug window or log file).



Version History
v1.60
- Fix: exclude MC from auto training Routine
- Fix: swim together on nude beach no longer puts on swimsuits
- Fix: ai workout together check if main actor has already worked out
- Fix: set workout flag correctly for both participants in workout together
- Fix: workout together ai choice None chance to 0 to prevent multiple triggers
- Tweak: ai char needs more stamina before doing automatic workout session (leave enough stamina for other activities)
- Add: entry to debug log when character does auto training at gym
v1.59
- Add: cheat set college degree for employee to current job
- Tweak: employee cheats are now in a separate page
- Tweak: allow for a max of 30 images when changing appearance
- Fix: choice error in cheat screen by moving employee cheats to separate page
v1.58
- Add: cheat set opinions / attributes for commissioners to make passing laws easier
- Fix: mc set sex opinions cheat did not apply likes / dislikes correctly according to gender and sexual orientation
- Fix: don't set incest and rape options when taboo is not enabled
- Fix: track romantic partner relationship setting and eternal_love modifier using flags for more concise cheat menu
v1.57
- Fix: prevent auto workout / swim of AI with MC and skip time slot
- Fix: don't set skin and ethnic values when taboo racism is set
v1.56
- Add: take someone swimming in a Club pool (when pool available) with possible naughty aftermath.
- Add: show months played in cheat MC dialog body.
- Add: Job information, college degree and attractiveness to '<Cheat Char>' main window (attractiveness is a hidden stat that is important for some jobs)
- Tweak: 'set baseline job' now also sets fixed attributes important for job (might change 'make attracted to MC' values and vice versa)
- Tweak: set sex likes for male characters (set anal_r, sex_same_sex based on orientation)
- Fix: disable some cheats on special story characters to prevent breaking story lines.
- Fix: Execute saw_someone_naked() function when stripping nude while going swimming.
- Fix: only add good_friends modifier to friends (no longer adds to acquaintances)
- Fix: instead of &id_to_char(3) use &get_mc() function
v1.55
- Add: Allow enable/disable parts of the MOD by using the configuration screen available through the '<Cheat MC>' option in your office
- Add: stable relations now include modifiers for friends and followers (after taking over Moral Police)
V1.54
- Add: stable relations modifiers for romantic partners and employees (increased opinion and happiness, less micro-management)
- Fix: cheat uncover trait attributes not working as intended
- Fix: set minimal lewd value for strip club employees to 1 (prevents high negative lewd value, even if lewdness not required by job)
- Fix: set person cheat_ok flag for poly / wholesome relationship to true / false
- Fix: cheat change character image, handle poses with underscore in pose name (white squares would be visible)
- Improved: debug info when activating character cheat and added character ID to window title (for using console)
v1.53
- Add: Cheat any character learn her attributes and opinions (learn by category)
- Add: MC cheat add 3 new AI characters option (configurable age, gender and sexual orientation)
v1.52
- Fix: remove 'eternal_love' modifier didn't work
v1.51
- Add: new cheat option add 'eternal love' modifier, basically preventing attraction decay for character (removable)
- Add: extra logging of values -> requires enable logging in king_cheat.tfl file
- Change: lewdness is now set according to job requirement (+5) when using employee cheat make good at current job
- Change: different values for health and happiness for MC (90) or employee (70)
- Fix: job_skill is a read-only property that cannot be set (contrary to cheat sheet info)
- Fix: correctly set leadership like value (to negative -> employees love a boss)
- Fix: set sex likes was missing a few opinions
v1.5
- Updated for SCW2.01
- Remove: Go to office (now in base game)
- Tweak: values set during make her good at her job cheat command
v1.42
- Add: moved MC to separate option in Office "<Cheat MC>" and is no longer applied during character cheats
- Tweak: cheat mod match opinion with MC to no longer match sexual opinions (minor options only)
- Tweak: employees love following and hate leading (better work stats)
- Fix: Changing character images only available when config setting (allow_pick_image is set to true in config.dat / user_config.dat)
- Fix: Swimming title not loaded correctly
v1.41
- Fix: set health not working as intended
v1.4
- Add: comprehensive cheat module for random people, employees and romantic partners
- Fix: add title to swim fun
- Fix: goto auxiliary only visible when room available
- Fix: switch to nude beach only available when unlocked
v1.3
- Fix: runtime error after beach fun
v1.2
- Add: Swimming Together option at beach
- Add: When in office show Go to auxiliary to quickly switch between offices
- Tweak: modifiers a little based on feedback from TotalFluke
v1.1
- Add: Financial Aid event
- Fix: modifiers not applied correctly
v1.0
- Initial Release
